<?php
date_default_timezone_set("Asia/Baghdad");
if (file_exists('madeline.php')){
    require_once 'madeline.php';
}
define('MADELINE_BRANCH', 'deprecated');
function bot($method, $datas = []){
    $token = file_get_contents("6013181137:AAHR6CGZcOwofGYKpTg5b0hOHIVbNHR9R8U");
    $url = "https://api.telegram.org/bot$token/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}
$settings['app_info']['api_id'] = 20331403;
$settings['app_info']['api_hash'] = '85124e7aef89185e581aa2169f974dcf';
$MadelineProto = new \danog\MadelineProto\API('d.madeline',$settings);
require("conf.php"); 
$TT = file_get_contents("token");
$tg = new Telegram("$TT");
$lastupdid = 1; 
while(true){ 
 $upd = $tg->vtcor("getUpdates", ["offset" => $lastupdid]); 
 if(isset($upd['result'][0])){ 
  $text = $upd['result'][0]['message']['text']; 
  $chat_id = $upd['result'][0]['message']['chat']['id']; 
$from_id = $upd['result'][0]['message']['from']['id']; 
$sudo = file_get_contents("ID");;
if($from_id == $sudo){
try{
if(file_get_contents("step4") == "2"){
if($text !== "Login4"){
  file_put_contents('phone4',$text);
$MadelineProto->phonelogin($text);
$tg->vtcor('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"⌁ Checker number - 4 - \n⌁ Send Code Phone Now \n⌁ Ex : - 67467 -",
]);
file_put_contents("step4","3");
}
}elseif(file_get_contents("step4") == "3"){
if($text){
$authorization = $MadelineProto->completephonelogin($text);
if ($authorization['_'] === 'account.password') {
$tg->vtcor('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"⌁ Checker number - 4 - \n⌁ Send password \n⌁ Ex : - karrar- ",
]);
file_put_contents("step4","4");
}else{
$tg->vtcor('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"⌁ Checker number - 4 - \n⌁ Done Login ✅",
]);
file_put_contents("step4","");
exit;
}
}
}elseif(file_get_contents("step4") == "4"){
if($text){
$authorization = $MadelineProto->complete2falogin($text);
$tg->vtcor('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"⌁ Checker number - 4 - \n⌁ Done Login ✅",
]);
file_put_contents("step4","");
exit;
}
}
}catch(Exception $e) {
  $tg->vtcor('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- There is Errors try again.",
]);
exit;
}}
$lastupdid = $upd['result'][0]['update_id'] + 1;
}
}