<?php

namespace danog\MadelineProto\Ipc\Wrapper;

class SeekableInputStream extends InputStream
{
    use SeekableTrait;
}
